path_csv = 'auto-mpg.csv'

try:
    f = open(path_csv,"r",encoding="utf-8")
    
    content = f.readlines()
    
    print(content)
except:
    print("Voce nao gosta de carros!")
