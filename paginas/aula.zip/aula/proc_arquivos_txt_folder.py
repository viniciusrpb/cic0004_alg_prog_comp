import os

def imprimeArquivo(path_file):
    
    f = open(path_file,'r',encoding='utf-8')
    
    content = f.readlines()
    
    string = ""
    for linha in content:
        string+=linha
        
    f.close()
    
    return string

path_folder = 'subfolder/'

if os.path.isdir(path_folder):
    print(f"Abrindo {path_folder}")
    
    lista_arquivos = os.listdir(path_folder)
    
    # ordena 
    lista_arquivos.sort()
    
    for arquivo in lista_arquivos:
        if os.path.isfile(path_folder+arquivo):
            print(f"Arquivo: {path_folder+arquivo}")
            print("Metadata")
            print(f"tamanho: {os.path.getsize(path_folder+arquivo)} bytes")
            conteudo = imprimeArquivo(path_folder+arquivo)
            print(conteudo+"\n")
        else:
            print(f"Diretorio: {path_folder+arquivo}")
    
else:
    print(f"{path_folder} nao eh valido")
    

