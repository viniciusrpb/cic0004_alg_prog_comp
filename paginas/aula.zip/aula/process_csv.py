path_csv = 'auto-mpg.csv'

try:
    f = open(path_csv,"r",encoding="utf-8")
    
    content = f.readlines()
    
    #print(content)
    
    id_linha = 0
    attributes = content[id_linha][:-1].split(',')
    id_linha+=1
    #print(attributes)
    #string = ""
    matriz = []
    while id_linha < len(content):
        matriz.append(content[id_linha][:-1].split(','))
        id_linha+=1
    
    string = ""
    for i in range(0,len(matriz)):
        linha_string = ""
        for a in range(0,len(matriz[i])-1):
            linha_string+=str(matriz[i][a])+";"
        linha_string +=str(matriz[i][len(matriz[i])-1])
        string+=linha_string+"\n"
    
    print(string)
    
    fout = open('saida_pv.csv','w',encoding='utf-8')
    fout.write(string)
    fout.close()
    
    f.close()
except:
    print("Voce nao gosta de carros!")
