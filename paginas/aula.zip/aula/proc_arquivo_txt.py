path_file = 'subfolder/arq1.txt'
mode = "r"

try:
    f = open(path_file,mode)

    # Verifica o tipo do arquivo
    print(type(f))

    # Leitura de um arquivo de texto linha a linha
    linha = f.readline()
    while linha != '':
        print(f"comprimento da linha: {len(linha)}")
        print(linha[:-1])
        linha = f.readline()

    f.close()
except:
    print("Algo esta muito errado!")
    
print("Segue o jogo...")


    



